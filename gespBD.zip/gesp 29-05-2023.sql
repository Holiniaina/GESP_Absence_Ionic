-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 29 mai 2023 à 09:29
-- Version du serveur :  8.0.21
-- Version de PHP :  7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gesp`
--

-- --------------------------------------------------------

--
-- Structure de la table `absence`
--

DROP TABLE IF EXISTS `absence`;
CREATE TABLE IF NOT EXISTS `absence` (
  `idabsence` int NOT NULL AUTO_INCREMENT,
  `liste_absent` varchar(45) DEFAULT NULL,
  `date_ajout_absence` date DEFAULT NULL,
  `isjustified` tinyint DEFAULT NULL,
  `cours_idcours` int NOT NULL,
  `personel_idpersonel` int NOT NULL,
  PRIMARY KEY (`idabsence`),
  KEY `fk_absence_cours1_idx` (`cours_idcours`),
  KEY `fk_absence_personel1_idx` (`personel_idpersonel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `annee_academique`
--

DROP TABLE IF EXISTS `annee_academique`;
CREATE TABLE IF NOT EXISTS `annee_academique` (
  `id_annee_academique` int NOT NULL AUTO_INCREMENT,
  `annee_academique_libelle` varchar(45) DEFAULT NULL,
  `annee_academique_etat` tinyint DEFAULT NULL,
  PRIMARY KEY (`id_annee_academique`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `annee_academique`
--

INSERT INTO `annee_academique` (`id_annee_academique`, `annee_academique_libelle`, `annee_academique_etat`) VALUES
(1, '2023', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `branche`
--

DROP TABLE IF EXISTS `branche`;
CREATE TABLE IF NOT EXISTS `branche` (
  `id_branche` int NOT NULL AUTO_INCREMENT,
  `branche_libelle` varchar(45) DEFAULT NULL,
  `branche_etat` tinyint DEFAULT NULL,
  `an_acad_id_an_acad` int NOT NULL,
  PRIMARY KEY (`id_branche`),
  KEY `fk_branche_annee_academique_idx` (`an_acad_id_an_acad`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `branche`
--

INSERT INTO `branche` (`id_branche`, `branche_libelle`, `branche_etat`, `an_acad_id_an_acad`) VALUES
(1, 'informatique', NULL, 1),
(2, 'gestion', NULL, 1);

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

DROP TABLE IF EXISTS `cours`;
CREATE TABLE IF NOT EXISTS `cours` (
  `idcours` int NOT NULL AUTO_INCREMENT,
  `contenu` text,
  `coef` varchar(45) DEFAULT NULL,
  `credit` varchar(45) DEFAULT NULL,
  `courscol` varchar(45) DEFAULT NULL,
  `module_id_module` int NOT NULL,
  PRIMARY KEY (`idcours`),
  KEY `fk_cours_module2_idx` (`module_id_module`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `cours`
--

INSERT INTO `cours` (`idcours`, `contenu`, `coef`, `credit`, `courscol`, `module_id_module`) VALUES
(1, 'Node js', '4', '10', NULL, 1),
(2, 'Ionic', '4', '10', NULL, 2);

-- --------------------------------------------------------

--
-- Structure de la table `decaissement`
--

DROP TABLE IF EXISTS `decaissement`;
CREATE TABLE IF NOT EXISTS `decaissement` (
  `iddecaissement` int NOT NULL AUTO_INCREMENT,
  `decaissement_mnt` varchar(45) DEFAULT NULL,
  `decaissement_date` datetime DEFAULT NULL,
  `decaissement_motif` varchar(45) DEFAULT NULL,
  `personel_idpersonel` int NOT NULL,
  PRIMARY KEY (`iddecaissement`),
  KEY `fk_decaissement_personel1_idx` (`personel_idpersonel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `encaissement`
--

DROP TABLE IF EXISTS `encaissement`;
CREATE TABLE IF NOT EXISTS `encaissement` (
  `id_encaissement` int NOT NULL AUTO_INCREMENT,
  `encaissement_mnt` float DEFAULT NULL,
  `encaissement_date` datetime DEFAULT NULL,
  `type_finance_id_type_finance` int NOT NULL,
  `Etudiant_id_Etudiant` int NOT NULL,
  PRIMARY KEY (`id_encaissement`),
  KEY `fk_encaissement_type_finance1_idx` (`type_finance_id_type_finance`),
  KEY `fk_encaissement_Etudiant1_idx` (`Etudiant_id_Etudiant`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

DROP TABLE IF EXISTS `etudiant`;
CREATE TABLE IF NOT EXISTS `etudiant` (
  `id_Etudiant` int NOT NULL AUTO_INCREMENT,
  `Etudiant_matricule` varchar(45) DEFAULT NULL,
  `Etudiant_nom` varchar(45) DEFAULT NULL,
  `niveau_id_niveau` int NOT NULL,
  `utilisateur_idutilisateur` int NOT NULL,
  PRIMARY KEY (`id_Etudiant`),
  UNIQUE KEY `Etudiant_matricule_UNIQUE` (`Etudiant_matricule`),
  KEY `fk_Etudiant_niveau1_idx` (`niveau_id_niveau`),
  KEY `fk_etudiant_utilisateur1_idx` (`utilisateur_idutilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`id_Etudiant`, `Etudiant_matricule`, `Etudiant_nom`, `niveau_id_niveau`, `utilisateur_idutilisateur`) VALUES
(1, '235401', 'lolo', 2, 3),
(2, '235402', 'lala', 2, 4);

-- --------------------------------------------------------

--
-- Structure de la table `historique_ecolage`
--

DROP TABLE IF EXISTS `historique_ecolage`;
CREATE TABLE IF NOT EXISTS `historique_ecolage` (
  `id_historique_ecolage` int NOT NULL AUTO_INCREMENT,
  `historique_ecolage_mnt` float DEFAULT NULL,
  `historique_ecolage_annee` year DEFAULT NULL,
  `niveau_id_niveau` int NOT NULL,
  PRIMARY KEY (`id_historique_ecolage`),
  KEY `fk_historique_ecolage_niveau1_idx` (`niveau_id_niveau`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

DROP TABLE IF EXISTS `module`;
CREATE TABLE IF NOT EXISTS `module` (
  `id_module` int NOT NULL AUTO_INCREMENT,
  `module_libelle` varchar(45) DEFAULT NULL,
  `module_etat` tinyint DEFAULT NULL,
  `semestre_id_semestre` int NOT NULL,
  PRIMARY KEY (`id_module`),
  KEY `fk_module_semestre1_idx` (`semestre_id_semestre`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `module`
--

INSERT INTO `module` (`id_module`, `module_libelle`, `module_etat`, `semestre_id_semestre`) VALUES
(1, 'Technologie web I', NULL, 1),
(2, 'Technologie web II', NULL, 2);

-- --------------------------------------------------------

--
-- Structure de la table `niveau`
--

DROP TABLE IF EXISTS `niveau`;
CREATE TABLE IF NOT EXISTS `niveau` (
  `id_niveau` int NOT NULL AUTO_INCREMENT,
  `niveau_libelle` varchar(45) DEFAULT NULL,
  `parcours_id_parcours` int NOT NULL,
  PRIMARY KEY (`id_niveau`),
  KEY `fk_niveau_parcours1_idx` (`parcours_id_parcours`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `niveau`
--

INSERT INTO `niveau` (`id_niveau`, `niveau_libelle`, `parcours_id_parcours`) VALUES
(1, 'M1', 1),
(2, 'M2', 1);

-- --------------------------------------------------------

--
-- Structure de la table `parcours`
--

DROP TABLE IF EXISTS `parcours`;
CREATE TABLE IF NOT EXISTS `parcours` (
  `id_parcours` int NOT NULL AUTO_INCREMENT,
  `parcours_libelle` varchar(45) DEFAULT NULL,
  `parcours_etat` tinyint DEFAULT NULL,
  `branche_id_branche` int NOT NULL,
  PRIMARY KEY (`id_parcours`),
  KEY `fk_parcours_branche1_idx` (`branche_id_branche`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `parcours`
--

INSERT INTO `parcours` (`id_parcours`, `parcours_libelle`, `parcours_etat`, `branche_id_branche`) VALUES
(1, 'informatique de gestion', NULL, 1),
(2, 'informatique Telecom', NULL, 1);

-- --------------------------------------------------------

--
-- Structure de la table `personel`
--

DROP TABLE IF EXISTS `personel`;
CREATE TABLE IF NOT EXISTS `personel` (
  `idpersonel` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(45) DEFAULT NULL,
  `utilisateur_idutilisateur` int NOT NULL,
  PRIMARY KEY (`idpersonel`),
  KEY `fk_personel_utilisateur1_idx` (`utilisateur_idutilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `personel`
--

INSERT INTO `personel` (`idpersonel`, `nom`, `utilisateur_idutilisateur`) VALUES
(1, 'angelo', 2),
(2, 'prisca', 1);

-- --------------------------------------------------------

--
-- Structure de la table `semestre`
--

DROP TABLE IF EXISTS `semestre`;
CREATE TABLE IF NOT EXISTS `semestre` (
  `id_semestre` int NOT NULL AUTO_INCREMENT,
  `semestre_libelle` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `semestre_etat` tinyint DEFAULT NULL,
  `annee_academique_id_annee_academique` int NOT NULL,
  PRIMARY KEY (`id_semestre`),
  KEY `fk_semestre_annee_academique1_idx` (`annee_academique_id_annee_academique`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `semestre`
--

INSERT INTO `semestre` (`id_semestre`, `semestre_libelle`, `semestre_etat`, `annee_academique_id_annee_academique`) VALUES
(1, 's1', NULL, 1),
(2, 's2', NULL, 1);

-- --------------------------------------------------------

--
-- Structure de la table `tresorerie`
--

DROP TABLE IF EXISTS `tresorerie`;
CREATE TABLE IF NOT EXISTS `tresorerie` (
  `id_tresorerie` int NOT NULL AUTO_INCREMENT,
  `tresorerie_budget` float DEFAULT NULL,
  `encaissement_id_encaissement` int NOT NULL,
  `decaissement_iddecaissement` int NOT NULL,
  PRIMARY KEY (`id_tresorerie`),
  KEY `fk_tresorerie_encaissement1_idx` (`encaissement_id_encaissement`),
  KEY `fk_tresorerie_decaissement1_idx` (`decaissement_iddecaissement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `type_finance`
--

DROP TABLE IF EXISTS `type_finance`;
CREATE TABLE IF NOT EXISTS `type_finance` (
  `id_type_finance` int NOT NULL AUTO_INCREMENT,
  `type_finance_libelle` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_type_finance`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `type_user`
--

DROP TABLE IF EXISTS `type_user`;
CREATE TABLE IF NOT EXISTS `type_user` (
  `idtype_user` int NOT NULL AUTO_INCREMENT,
  `libelle_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`idtype_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `type_user`
--

INSERT INTO `type_user` (`idtype_user`, `libelle_type`) VALUES
(1, 'admin'),
(2, 'prof'),
(3, 'etudiant');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `idutilisateur` int NOT NULL AUTO_INCREMENT,
  `email` varchar(45) DEFAULT NULL,
  `psw` varchar(45) DEFAULT NULL,
  `type_user_idtype_user` int NOT NULL,
  PRIMARY KEY (`idutilisateur`),
  KEY `fk_utilisateur_type_user1_idx` (`type_user_idtype_user`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`idutilisateur`, `email`, `psw`, `type_user_idtype_user`) VALUES
(1, 'prisca@yahoo.com', 'prisca', 1),
(2, 'angelo@yahoo.com', 'angelo', 2),
(3, 'lolo@yahoo.com', 'lolo', 3),
(4, 'lala@yahoo.com', 'lala', 3);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `absence`
--
ALTER TABLE `absence`
  ADD CONSTRAINT `fk_absence_cours1` FOREIGN KEY (`cours_idcours`) REFERENCES `cours` (`idcours`),
  ADD CONSTRAINT `fk_absence_personel1` FOREIGN KEY (`personel_idpersonel`) REFERENCES `personel` (`idpersonel`);

--
-- Contraintes pour la table `branche`
--
ALTER TABLE `branche`
  ADD CONSTRAINT `fk_branche_annee_academique` FOREIGN KEY (`an_acad_id_an_acad`) REFERENCES `annee_academique` (`id_annee_academique`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `cours`
--
ALTER TABLE `cours`
  ADD CONSTRAINT `fk_cours_module2` FOREIGN KEY (`module_id_module`) REFERENCES `module` (`id_module`);

--
-- Contraintes pour la table `decaissement`
--
ALTER TABLE `decaissement`
  ADD CONSTRAINT `fk_decaissement_personel1` FOREIGN KEY (`personel_idpersonel`) REFERENCES `personel` (`idpersonel`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `encaissement`
--
ALTER TABLE `encaissement`
  ADD CONSTRAINT `fk_encaissement_Etudiant1` FOREIGN KEY (`Etudiant_id_Etudiant`) REFERENCES `etudiant` (`id_Etudiant`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_encaissement_type_finance1` FOREIGN KEY (`type_finance_id_type_finance`) REFERENCES `type_finance` (`id_type_finance`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD CONSTRAINT `fk_Etudiant_niveau1` FOREIGN KEY (`niveau_id_niveau`) REFERENCES `niveau` (`id_niveau`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_etudiant_utilisateur1` FOREIGN KEY (`utilisateur_idutilisateur`) REFERENCES `utilisateur` (`idutilisateur`);

--
-- Contraintes pour la table `historique_ecolage`
--
ALTER TABLE `historique_ecolage`
  ADD CONSTRAINT `fk_historique_ecolage_niveau1` FOREIGN KEY (`niveau_id_niveau`) REFERENCES `niveau` (`id_niveau`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `module`
--
ALTER TABLE `module`
  ADD CONSTRAINT `fk_module_semestre1` FOREIGN KEY (`semestre_id_semestre`) REFERENCES `semestre` (`id_semestre`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `niveau`
--
ALTER TABLE `niveau`
  ADD CONSTRAINT `fk_niveau_parcours1` FOREIGN KEY (`parcours_id_parcours`) REFERENCES `parcours` (`id_parcours`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `parcours`
--
ALTER TABLE `parcours`
  ADD CONSTRAINT `fk_parcours_branche1` FOREIGN KEY (`branche_id_branche`) REFERENCES `branche` (`id_branche`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `personel`
--
ALTER TABLE `personel`
  ADD CONSTRAINT `fk_personel_utilisateur1` FOREIGN KEY (`utilisateur_idutilisateur`) REFERENCES `utilisateur` (`idutilisateur`);

--
-- Contraintes pour la table `semestre`
--
ALTER TABLE `semestre`
  ADD CONSTRAINT `fk_semestre_annee_academique1` FOREIGN KEY (`annee_academique_id_annee_academique`) REFERENCES `annee_academique` (`id_annee_academique`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `tresorerie`
--
ALTER TABLE `tresorerie`
  ADD CONSTRAINT `fk_tresorerie_decaissement1` FOREIGN KEY (`decaissement_iddecaissement`) REFERENCES `decaissement` (`iddecaissement`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tresorerie_encaissement1` FOREIGN KEY (`encaissement_id_encaissement`) REFERENCES `encaissement` (`id_encaissement`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `fk_utilisateur_type_user1` FOREIGN KEY (`type_user_idtype_user`) REFERENCES `type_user` (`idtype_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
