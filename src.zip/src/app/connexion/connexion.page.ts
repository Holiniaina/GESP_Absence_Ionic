import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController, NavController } from '@ionic/angular';
import { UTILISATEUR } from 'src/model/user/utilisateur';
import { UTILISATEURService } from 'src/service/user/utilisateur.service';

@Component({
  selector: 'app-connexion',
  templateUrl: './connexion.page.html',
  styleUrls: ['./connexion.page.scss'],
})
export class ConnexionPage implements OnInit {
  public _user = new UTILISATEUR
  public user_id : any
  public user_type : any
  public user_nom : any
  message_succes : any
  constructor(
    public utilisateurService : UTILISATEURService,
    public router : Router,
    private toast: ToastController,
    private cdRef : ChangeDetectorRef,
    private navCTrl : NavController
  ) {

  }

  ngOnInit() {
  }

  async message( message: any, duration: any, position:any, color: any){
      const toast = await this.toast.create({
        message: message,
        duration: duration,
        position: position,
        color: color
      });
      toast.present();
      return
  }
  async connexion(){
    //Si champs vides
    if(this._user.email == ""){
      this.message( 'Entrez votre email', 2000, 'bottom', 'danger')
    }
    if(this._user.psw == ""){
      this.message( 'Entrez votre mot de passe', 2000, 'bottom', 'danger')
    }
    //Verification connexion utilisateur
    this.utilisateurService.loginUserService(this._user).subscribe(async data => {
        //console.log(data.json().id_user )
        if (data.json() != null) {
          sessionStorage.setItem("user_id", JSON.stringify(data.json().idutilisateur))
          sessionStorage.setItem("user_type", JSON.stringify(data.json().type_user_idtype_user))
          sessionStorage.setItem("user_nom", JSON.stringify(data.json().email))

          this.user_id = JSON.parse(JSON.stringify(sessionStorage.getItem("user_id"))).replace(/"/g,'')
          this.user_type = JSON.parse(JSON.stringify(sessionStorage.getItem("user_type"))).replace(/"/g,'')
          this.user_nom = JSON.parse(JSON.stringify(sessionStorage.getItem("user_nom"))).replace(/"/g,'')

          console.log(this.user_id + "-" +this.user_type)

          this.router.navigate(['/absence'])
          this.message( "Bienvenue "+this.user_nom, 1000, 'bottom', 'success')
      
          //location.reload()
          //this.navCTrl.navigateRoot('/connexion')
          console.log(this.user_id + "-" +this.user_type)

          // return this.message_succes = "success"

        } else {
          
          this.message( "Données incorectes !!!", 2000, 'bottom', 'danger')
          // return this.message_succes = "erreur"
        }
      }
    );
    // this._user.email = "";
    // this._user.psw = "";
  }


}
