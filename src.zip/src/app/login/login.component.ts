import { Component, OnInit } from '@angular/core';
import {UTILISATEURService} from "../../service/user/utilisateur.service";
import {UTILISATEUR} from "../../model/user/utilisateur";
import {TYPE} from "../../model/type/type";
import {Router} from "@angular/router";
import {FormBuilder} from "@angular/forms";
import { Response } from '@angular/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {

  _utilisateur : UTILISATEUR = new UTILISATEUR();
  _type_user : TYPE = new TYPE();

  public users: Array<any>=[];
  public type_users: Array<any>=[];
  idtype: any;
  afficher : any;
  presence: any;
  ischecked: any[] = [];
  check: any ;
  idChecked: any[] = [];

  constructor(public utilisateurService : UTILISATEURService,public router : Router) {
  //requete select users, atao anaty array d aveo affichena
    this.utilisateurService.selecTypetUsers(this._type_user).subscribe((data) => {
      this.type_users = Array.from(Object.keys(data.json()), k=>data.json()[k]);
      // console.log(this.type_users)
      this.findData(this.type_users[0].idutilisateur)

    })

  }

  ngOnInit() {
    // @ts-ignore

    this.ischecked =[]
    this.idChecked =[]
  }

   findData(idType:any){
    this.utilisateurService.selectUsersByType(this._utilisateur, idType).subscribe((data) => {
      this.users = Array.from(Object.keys(data.json()), k=>data.json()[k]);
      //console.log(this.users)
    })
  }

  async afficherListeUsersSelonType(){
    this.idChecked = []
    this.idtype =(<HTMLInputElement>document.getElementById('type')).value;
    if (this.idtype) {
      this.findData(this.idtype)

    }
    else {
      // this.utilisateurService.selectUsers(this._utilisateur).subscribe((data) => {
      //   this.users = Array.from(Object.keys(data.json()), k=>data.json()[k]);
      // console.log(this.users)

      // })

    }
  }
  insertAbsent(){
    console.log(this.idChecked)

  }

  getCheckedUser(user: any, event:any){
    if (event.detail.checked) {
      this.idChecked.push(user.id_user)

    } else {
      let index = this.idChecked.indexOf(user.id_user)
      if (index !== -1) {
        this.idChecked.splice(index, 1)
      }
    }
   // console.log(this.idChecked)
  }

  // async getCheckedUser(){

  //   for (let i = 0; i < this.ischecked.length; i++) {
  //     if (this.ischecked[i]) {
  //       this.idChecked[i] = this.ischecked[i]

  //     } else {
  //       this.idChecked[i] = ""
  //       console.log("Checkbox "+i+" is not checked")
  //     }

  //   }
  //   console.log(this.ischecked)

  // }

  loginUser(){

   // var sqlite = require(s)

    this._utilisateur.email = (<HTMLInputElement>document.getElementById('exampleInputEmail')).value;
    this._utilisateur.psw = (<HTMLInputElement>document.getElementById('exampleInputPassword')).value;

    // @ts-ignore
    this.utilisateurService.loginUserService(this._utilisateur).subscribe(data => {

      this.router.navigate(['/tabs/tab1/signup'])


      console.log(data.json())
    })

  }


}
