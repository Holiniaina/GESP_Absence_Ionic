import { Component, OnInit } from '@angular/core';
import { ToastController, NavController } from '@ionic/angular';
import {Router} from "@angular/router";
import {FormBuilder} from "@angular/forms";
import {UTILISATEURService} from "../../service/user/utilisateur.service";
import { AnneeAcademique } from '../../model/annee_academique/annee-academique';
import {Parcours} from "../../model/parcours/parcours";
import {Cours} from "../../model/cours/cours";
import {Niveau} from "../../model/niveau/niveau";
import {Etudiant} from "../../model/etudiant/etudiant";
import {Absence} from "../../model/absence/absence";

@Component({
  selector: 'app-absence',
  templateUrl: './absence.page.html',
  styleUrls: ['./absence.page.scss'],
})
export class AbsencePage implements OnInit {
  public _annee_academique = new AnneeAcademique
  public _parcours = new Parcours
  public _niveau = new Niveau
  public _cours = new Cours
  public _etudiant = new Etudiant
  public _absence = new Absence  
  public list_annee: any =[];
  public list_parcours: any =[];
  public list_niveau: any =[];
  public list_cours: any =[];
  public list_etudiant: any =[];
  public list_absence: any =[];
  public list_absence_temp: any =[];
  idChecked: any[] = [];
  public idAbsence:Array<any>=[];
  idabs : any
  annee:any
  niveau:any
  parcours:any
  cours:any
  totalAbsents:any = 0
  constructor(public utilisateurService : UTILISATEURService,public router : Router,
    private toast: ToastController) { }

  ngOnInit() {
    this.utilisateurService.selectAnnee(this._annee_academique).subscribe((data) => {
      this.list_annee = Array.from(Object.keys(data.json()), k=>data.json()[k]);
      // console.log(this.list_annee)

      this.utilisateurService.selectParcours(this._parcours).subscribe((data) => {
        this.list_parcours = Array.from(Object.keys(data.json()), k=>data.json()[k]);
       // console.log(this.list_parcours)
        
        this.utilisateurService.selectNiveau(this._niveau).subscribe((data) => {
          this.list_niveau = Array.from(Object.keys(data.json()), k=>data.json()[k]);
          // console.log(this.list_niveau)
          
          this.utilisateurService.selectCours(this.cours).subscribe((data) => {
            this.list_cours = Array.from(Object.keys(data.json()), k=>data.json()[k]);
            // console.log(this.list_cours)
            
      
          })

    
        })
  
      })
    })

    
  }

  async message( message: any, duration: any, position:any, color: any){
    const toast = await this.toast.create({
      message: message,
      duration: duration,
      position: position,
      color: color
    });
    toast.present();
    return
  }

  updateAbsent(){
    console.log("id :"+this.idabs)
    console.log(this.idChecked)
    this._absence.idabsence = this.idabs
    this._absence.liste_absent = JSON.stringify(this.idChecked)
   this.utilisateurService.updateAbsent(this._absence)
   this.message( 'Données modifiées avec succès', 2000, 'bottom', 'success')
    //console.log(this._absence.liste_absent)
  }

  insertAbsent(){
    this._absence.cours_idcours =(<HTMLInputElement>document.getElementById('cours')).value;
    this._absence.date_ajout_absence =(<HTMLInputElement>document.getElementById('dateAbsence')).value;
    this._absence.liste_absent = JSON.stringify(this.idChecked)
   this.utilisateurService.insertAbsent(this._absence)
   this.message( 'Données enregistrées avec succès', 2000, 'bottom', 'success')
    //console.log(this._absence.liste_absent)
  }

  getCheckedId(etudiant: any, event:any){
    if (event.detail.checked) {
        this.idChecked.push(etudiant.id_Etudiant)

    } else {
      let index = this.idChecked.indexOf(etudiant.id_Etudiant)
      if (index !== -1) {
        this.idChecked.splice(index, 1)
      }
    }
    console.log(this.idChecked)
    this.totalAbsents = this.idChecked.length
  }

  afficheAbsence(){
    this.idChecked.length = 0
    this.totalAbsents = 0
    this._absence.cours_idcours =(<HTMLInputElement>document.getElementById('cours')).value;
    this._absence.date_ajout_absence =(<HTMLInputElement>document.getElementById('dateAbsence')).value;
    if (this._absence.cours_idcours == 0) {
      this.message( 'Selectionnez un cours', 2000, 'bottom', 'danger')
    } 
    else if(this._absence.date_ajout_absence == null) {
      this.message( 'Selectionnez une date', 2000, 'bottom', 'danger')
    }else{
      this.utilisateurService.selectAbsence(this._absence).subscribe((data) => {
        this.list_absence = Array.from(Object.keys(data.json()), k=>data.json()[k]);
        if (this.list_absence[0] != null) {
          this.idAbsence.length = 0
          this.idabs = 0
          
          for (let i = 0; i < this.list_absence.length; i++) {
            this.idabs = this.list_absence[i].idabsence
            this.idAbsence[i] = JSON.parse(this.list_absence[i].liste_absent)
            
            
          }
          for (let i = 0; i < this.idAbsence[0].length; i++) {
            this.idChecked.push(this.idAbsence[0][i])
          }
          
          this.totalAbsents = this.idChecked.length
          console.log("ok "+this.idChecked)
          
        } else {
          this.idAbsence.length = 0
          this.idabs = 0
          
        }
        
     })

    }
   
    
  }

  afficheProm(){
    this._annee_academique.id_annee_academique =(<HTMLInputElement>document.getElementById('annee')).value;
    this._parcours.id_parcours =(<HTMLInputElement>document.getElementById('parcours')).value;
    this._niveau.id_niveau =(<HTMLInputElement>document.getElementById('niveau')).value;
    //console.log(this.annee)
    if (this._annee_academique.id_annee_academique == 0) {
      this.message( 'Selectionnez une année académique', 2000, 'bottom', 'danger')
    } 
    else if (this._parcours.id_parcours == 0) {
      this.message( 'Selectionnez un parcours', 2000, 'bottom', 'danger')
    } 
    else if(this._niveau.id_niveau == 0) {
      this.message( 'Selectionnez un niveau', 2000, 'bottom', 'danger')
    } else {
      this.utilisateurService.selectEtudiant(this._annee_academique, this._parcours, this._niveau).subscribe((data) => {
        this.list_etudiant = Array.from(Object.keys(data.json()), k=>data.json()[k]);
        console.log(this.list_etudiant)
        
  
      })
    }
   

  }
}
