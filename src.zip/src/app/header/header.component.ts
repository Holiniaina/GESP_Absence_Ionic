import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { UTILISATEUR } from 'src/model/user/utilisateur';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  _user = new UTILISATEUR
  user_id : any
  user_type : any

  constructor(private cdRef : ChangeDetectorRef, public router : Router) {

  }

  ngOnInit() {
    if (sessionStorage.getItem("user_id") != null && sessionStorage.getItem("user_type") != null) {
      this.user_id = JSON.parse(JSON.stringify(sessionStorage.getItem("user_id"))).replace(/"/g,'')
      this.user_type = JSON.parse(JSON.stringify(sessionStorage.getItem("user_type"))).replace(/"/g,'')

    } else {
    }


    console.log(this.user_id)

    this.cdRef.detectChanges()
  }
  deconnexion(){
    sessionStorage.removeItem("user_id")
    sessionStorage.removeItem("user_type")
    sessionStorage.removeItem("user_nom")
    this.router.navigate(['/connexion'])
  }


}
