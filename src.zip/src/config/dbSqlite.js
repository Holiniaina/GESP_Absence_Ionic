var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('SQLITE3');

module.exports = db
