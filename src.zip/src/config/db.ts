
var sqlite3 = require('sqlite3').verbose();


export class DB {

  static base(){
  return new sqlite3.Database('../..SQLITE3');
  }

   constructor() {

   }

}
