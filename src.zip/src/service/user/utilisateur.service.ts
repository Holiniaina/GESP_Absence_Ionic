import { Injectable } from '@angular/core';
import {UTILISATEUR} from "../../model/user/utilisateur";
import { AnneeAcademique } from '../../model/annee_academique/annee-academique';
import {Parcours} from "../../model/parcours/parcours";
import {Cours} from "../../model/cours/cours";
import {Niveau} from "../../model/niveau/niveau";
import {TYPE} from "../../model/type/type";
import {Etudiant} from "../../model/etudiant/etudiant";
import {Absence} from "../../model/absence/absence";
import {Http, RequestOptions} from "@angular/http";

@Injectable({
  providedIn: 'root'
})
export class UTILISATEURService {
  adress : any = "http://localhost/server/"
  constructor( public  Http : Http) { }

  updateAbsent(_absence : Absence){
    //id = _absence.idabsence
    let headers = new Headers();
    headers.append('Content-Type','application/x-www-form-urlencode; charset-UTF-8')
    let body = JSON.stringify(_absence);
    // @ts-ignore
    let option = new RequestOptions({headers : headers})

    return this.Http.post(this.adress+"Users/updateAbsence/"+_absence.idabsence,body,option).subscribe()


  }
  //updateAbsence
  insertAbsent(_absence : Absence){
    let headers = new Headers();
    headers.append('Content-Type','application/x-www-form-urlencode; charset-UTF-8')
    let body = JSON.stringify(_absence);
    // @ts-ignore
    let option = new RequestOptions({headers : headers})

    return this.Http.post(this.adress+"Users/createAbsence",body,option).subscribe()


  }

  selectAbsence(_absence : Absence){
    return this.Http.get(this.adress+"Users/find_absence/"+_absence.cours_idcours+"/"+_absence.date_ajout_absence)
  
  }

  selectEtudiant(_annee : AnneeAcademique, _parcours : Parcours, _niveau : Niveau){
    return this.Http.get(this.adress+"Users/find_etudiant/"+_annee.id_annee_academique+"/"+
    _parcours.id_parcours+"/"+_niveau.id_niveau)
  
  }

  selectParcours(_parcours : Parcours){
    return this.Http.get(this.adress+"Users/parcours")

  }
  selectCours(_cours : Cours){
    return this.Http.get(this.adress+"Users/cours")

  }
  selectNiveau(_niveau : Niveau){
    return this.Http.get(this.adress+"Users/niveau")

  }
  selectAnnee(_annee : AnneeAcademique){
    return this.Http.get(this.adress+"Users/annee_academique")

  }
  loginUserService(_Utilisateur : UTILISATEUR){
    ///manolotsoa.angelo
    return this.Http.get(this.adress+"Users/find_user_connect/"+_Utilisateur.email+"/"+_Utilisateur.psw)
  }

  saveUserService(_Utilisateur : UTILISATEUR){
    ////METHODE CRUD SERVER
    let headers = new Headers();
    headers.append('Content-Type','application/x-www-form-urlencode; charset-UTF-8')
    let body = JSON.stringify(_Utilisateur);
    // @ts-ignore
    let option = new RequestOptions({headers : headers})

    return this.Http.post(this.adress+"Users/createUser",body,option).subscribe()


  }
  selectUsers(_Utilisateur : UTILISATEUR){
    return this.Http.get(this.adress+"Users/")

  }
  selecTypetUsers(_Type_user : TYPE){
    return this.Http.get(this.adress+"Users/typeUsers")

  }
  selectUsersByType(_Utilisateur : UTILISATEUR, id_type: any){
    return this.Http.get(this.adress+"Users/find_user_by_type/"+id_type)

  }


}
