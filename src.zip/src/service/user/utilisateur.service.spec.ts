import { TestBed } from '@angular/core/testing';

import { UTILISATEURService } from './utilisateur.service';

describe('UTILISATEURService', () => {
  let service: UTILISATEURService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UTILISATEURService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
