import { TYPE } from './type';

describe('TYPE', () => {
  it('should create an instance', () => {
    expect(new TYPE()).toBeTruthy();
  });
});
