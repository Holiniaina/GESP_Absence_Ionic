export class TYPE {

  idtype_user : any;
  libelle_type : any;

    constructor(){}
    /*typeUsers(){

    }*/
  }
