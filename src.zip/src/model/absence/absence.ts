export class Absence {
    idabsence:any
    liste_absent:any
    date_ajout_absence:any
    isjustified:any
    cours_idcours:any
    personel_idpersonel:any
    constructor(){}
}
