import { Absence } from './absence';

describe('Absence', () => {
  it('should create an instance', () => {
    expect(new Absence()).toBeTruthy();
  });
});
