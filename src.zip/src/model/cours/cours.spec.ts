import { Cours } from './cours';

describe('Cours', () => {
  it('should create an instance', () => {
    expect(new Cours()).toBeTruthy();
  });
});
