export class Cours {
    idcours:any
    contenu:any
    coef:any
    credit:any
    courscol:any
    module_id_module:any
    constructor(){}
}
