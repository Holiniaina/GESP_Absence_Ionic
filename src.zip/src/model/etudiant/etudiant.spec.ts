import { Etudiant } from './etudiant';

describe('Etudiant', () => {
  it('should create an instance', () => {
    expect(new Etudiant()).toBeTruthy();
  });
});
