export class Etudiant {
    id_Etudiant:any
    Etudiant_matricule:any
    Etudiant_nom:any
    niveau_id_niveau:any
    utilisateur_idutilisateur:any
    constructor(){}
}
