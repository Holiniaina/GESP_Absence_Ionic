export class Niveau {
    id_niveau:any
    niveau_libelle:any
    parcours_id_parcours:any
    constructor(){}
}
