import { Niveau } from './niveau';

describe('Niveau', () => {
  it('should create an instance', () => {
    expect(new Niveau()).toBeTruthy();
  });
});
