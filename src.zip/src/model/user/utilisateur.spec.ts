import { UTILISATEUR } from './utilisateur';

describe('UTILISATEUR', () => {
  it('should create an instance', () => {
    expect(new UTILISATEUR()).toBeTruthy();
  });
});
