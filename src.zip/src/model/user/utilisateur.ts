export class UTILISATEUR {

    idutilisateur : any;
    nom_user : any;
    email : any;
    psw : any;
    type_user_idtype_user: any
    
    constructor(){}
  }

