export class Parcours {
    id_parcours:any
    parcours_libelle:any
    parcours_etat:any
    branche_id_branche:any
    constructor(){}
}
