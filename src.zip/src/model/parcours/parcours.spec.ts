import { Parcours } from './parcours';

describe('Parcours', () => {
  it('should create an instance', () => {
    expect(new Parcours()).toBeTruthy();
  });
});
