export class AnneeAcademique {
    id_annee_academique:any
    annee_academique_libelle:any
    annee_academique_etat:any

    constructor(){}
}
  