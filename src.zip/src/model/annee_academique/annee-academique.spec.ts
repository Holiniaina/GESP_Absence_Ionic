import { AnneeAcademique } from './annee-academique';

describe('AnneeAcademique', () => {
  it('should create an instance', () => {
    expect(new AnneeAcademique()).toBeTruthy();
  });
});
